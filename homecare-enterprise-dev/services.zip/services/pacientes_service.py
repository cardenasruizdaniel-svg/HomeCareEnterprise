"""
=========================================================
HomeCare IPS Enterprise
Servicio de Pacientes
Versión: 8.0.0 Enterprise
Sprint 1.3
=========================================================
"""

from datetime import datetime
from models.paciente import Paciente
from repositories.pacientes_repository import PacientesRepository
from core.audit.audit import crear_evento
from core.audit.writer import guardar_evento

class PacientesService:

    @staticmethod
    def listar():
        return PacientesRepository.listar()

    @staticmethod
    def obtener(paciente_id:int):
        return PacientesRepository.obtener_por_id(paciente_id)

    @staticmethod
    def buscar(texto:str):
        return PacientesRepository.buscar(texto)

    @staticmethod
    def guardar(datos:dict):
        paciente=Paciente(**datos)
        errores=paciente.validar()
        if errores:
            raise ValueError("\n".join(errores))
        resultado=PacientesRepository.insertar(paciente.to_dict())
        guardar_evento(crear_evento("sistema","CREAR","PACIENTES",paciente.documento))
        return resultado

    @staticmethod
    def actualizar(paciente_id:int,datos:dict):
        resultado=PacientesRepository.actualizar(paciente_id,datos)
        guardar_evento(crear_evento("sistema","ACTUALIZAR","PACIENTES",str(paciente_id)))
        return resultado

    @staticmethod
    def eliminar(paciente_id:int):
        resultado=PacientesRepository.eliminar(paciente_id)
        guardar_evento(crear_evento("sistema","ELIMINAR","PACIENTES",str(paciente_id)))
        return resultado
