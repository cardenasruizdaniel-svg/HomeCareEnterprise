from database.database import get_connection
import sqlite3


def obtener_dashboard():

    conexion = get_connection()
    cursor = conexion.cursor()

    def contar(sql):
        try:
            cursor.execute(sql)
            resultado = cursor.fetchone()
            return resultado[0] if resultado else 0
        except sqlite3.Error:
            return 0

    try:

        datos = {

            "total_pacientes": contar("""
                SELECT COUNT(*)
                FROM pacientes
            """),

            "total_profesionales": contar("""
                SELECT COUNT(*)
                FROM profesionales
            """),

            "visitas_programadas": contar("""
                SELECT COUNT(*)
                FROM programaciones
                WHERE estado='Programada'
            """),

            "visitas_en_curso": contar("""
                SELECT COUNT(*)
                FROM programaciones
                WHERE estado='En Curso'
            """),

            "visitas_completadas": contar("""
                SELECT COUNT(*)
                FROM programaciones
                WHERE estado='Completada'
            """),

            "visitas_canceladas": contar("""
                SELECT COUNT(*)
                FROM programaciones
                WHERE estado='Cancelada'
            """),

            "despachos_hoy": contar("""
                SELECT COUNT(*)
                FROM despachos
                WHERE DATE(fecha)=DATE('now')
            """),

            "despachos_pendientes": contar("""
                SELECT COUNT(*)
                FROM despachos
                WHERE estado='PENDIENTE'
            """),

            "despachos_en_ruta": contar("""
                SELECT COUNT(*)
                FROM despachos
                WHERE estado='EN_RUTA'
            """),

            "despachos_en_atencion": contar("""
                SELECT COUNT(*)
                FROM despachos
                WHERE estado='EN_ATENCION'
            """),

            "despachos_finalizados": contar("""
                SELECT COUNT(*)
                FROM despachos
                WHERE estado='FINALIZADO'
            """)

        }

        return datos

    finally:

        conexion.close()