from repositories.diagnosticos_repository import DiagnosticosRepository
class DiagnosticosService:
    @staticmethod
    def buscar(texto:str):
        return DiagnosticosRepository.buscar(texto)
