from core.interoperability.fhir_mapper import FHIRMapper

class InteroperabilidadService:
    @staticmethod
    def exportar_paciente(datos):
        return FHIRMapper.patient(datos)
