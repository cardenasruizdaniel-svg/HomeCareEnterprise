from repositories.ordenes_repository import OrdenesRepository
class OrdenesService:
    @staticmethod
    def listar(historia_id:int):
        return OrdenesRepository.listar(historia_id)
