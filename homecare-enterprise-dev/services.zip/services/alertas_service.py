from repositories.alertas_repository import (

    obtener_alergias,

    obtener_diagnosticos,

    obtener_proxima_visita

)


def obtener_alertas(paciente_id):

    alertas=[]

    # =====================
    # ALERGIAS
    # =====================

    alergias=obtener_alergias(paciente_id)

    for a in alergias:

        alertas.append({

            "tipo":"alergia",

            "nivel":a["severidad"],

            "mensaje":f"Alergia activa a {a['alergeno']}"

        })

    # =====================
    # DIAGNÓSTICOS
    # =====================

    diagnosticos=obtener_diagnosticos(paciente_id)

    for d in diagnosticos:

        alertas.append({

            "tipo":"diagnostico",

            "nivel":"Info",

            "mensaje":f"{d['codigo']} - {d['descripcion']}"

        })

    # =====================
    # VISITA
    # =====================

    visita=obtener_proxima_visita(paciente_id)

    if visita:

        alertas.append({

            "tipo":"agenda",

            "nivel":"Agenda",

            "mensaje":f"Próxima visita {visita['fecha']} {visita['hora_inicio']}"

        })

    return alertas