from repositories.programacion_repository import (

    listar,

    obtener,

    agenda_dia,

    agenda_profesional,

    agenda_paciente,

    pendientes,

    crear,

    cambiar_estado,

    eliminar

)


# ==========================================
# DASHBOARD
# ==========================================

def listar_programacion():

    return listar()


# ==========================================
# OBTENER VISITA
# ==========================================

def obtener_visita(id):

    return obtener(id)


# ==========================================
# AGENDA DEL DÍA
# ==========================================

def obtener_agenda_dia(fecha):

    return agenda_dia(fecha)


# ==========================================
# AGENDA PROFESIONAL
# ==========================================

def obtener_agenda_profesional(

    profesional_id,

    fecha

):

    return agenda_profesional(

        profesional_id,

        fecha

    )


# ==========================================
# AGENDA PACIENTE
# ==========================================

def obtener_agenda_paciente(

    paciente_id

):

    return agenda_paciente(

        paciente_id

    )


# ==========================================
# VISITAS PENDIENTES
# ==========================================

def visitas_pendientes():

    return pendientes()


# ==========================================
# CREAR VISITA
# ==========================================

def crear_visita(

    paciente_id,

    profesional_id,

    diagnostico_id,

    fecha,

    hora_inicio,

    hora_fin,

    duracion,

    servicio,

    procedimiento,

    prioridad,

    direccion,

    barrio,

    ciudad,

    departamento,

    telefono_contacto,

    nombre_contacto,

    observaciones,

    usuario

):

    # -----------------------------
    # VALIDACIONES
    # -----------------------------

    if paciente_id is None:

        raise Exception(

            "Debe seleccionar un paciente."

        )

    if profesional_id is None:

        raise Exception(

            "Debe seleccionar un profesional."

        )

    if fecha == "":

        raise Exception(

            "Debe seleccionar una fecha."

        )

    if hora_inicio == "":

        raise Exception(

            "Debe seleccionar una hora."

        )

    if servicio == "":

        raise Exception(

            "Debe indicar el servicio."

        )

    # -----------------------------
    # VALIDAR AGENDA PROFESIONAL
    # -----------------------------

    agenda = agenda_profesional(

        profesional_id,

        fecha

    )

    for visita in agenda:

        if visita["hora_inicio"] == hora_inicio:

            raise Exception(

                "El profesional ya tiene una visita programada en esa hora."

            )

    # -----------------------------
    # CREAR
    # -----------------------------

    crear(

        paciente_id,

        profesional_id,

        diagnostico_id,

        fecha,

        hora_inicio,

        hora_fin,

        duracion,

        servicio,

        procedimiento,

        prioridad,

        direccion,

        barrio,

        ciudad,

        departamento,

        telefono_contacto,

        nombre_contacto,

        observaciones,

        usuario

    )


# ==========================================
# CONFIRMAR VISITA
# ==========================================

def confirmar_visita(id):

    cambiar_estado(

        id,

        "Confirmada"

    )


# ==========================================
# INICIAR VISITA
# ==========================================

def iniciar_visita(id):

    cambiar_estado(

        id,

        "En Curso"

    )


# ==========================================
# FINALIZAR VISITA
# ==========================================

def finalizar_visita(id):

    cambiar_estado(

        id,

        "Completada"

    )


# ==========================================
# CANCELAR VISITA
# ==========================================

def cancelar_visita(id):

    cambiar_estado(

        id,

        "Cancelada"

    )


# ==========================================
# REPROGRAMAR VISITA
# ==========================================

def reprogramar_visita(id):

    cambiar_estado(

        id,

        "Reprogramada"

    )


# ==========================================
# ELIMINAR
# ==========================================

def eliminar_visita(id):

    eliminar(id)